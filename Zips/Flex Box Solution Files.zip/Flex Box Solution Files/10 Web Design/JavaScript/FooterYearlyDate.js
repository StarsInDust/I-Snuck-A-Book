// JavaScript Document
var year = new Date();document.write(year.getFullYear());






