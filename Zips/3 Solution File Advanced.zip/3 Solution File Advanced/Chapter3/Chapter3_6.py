
import copy


class Human:
    def __init__(self, name, age):
        self.name =name
        self.age = age
        

class Vet:
    def __init__(self, owner, groomer) :
        self.owner = owner
        self.groomer = groomer


person1 = Human('Joshua', 35)
person2 = Human('Jackson', 28)

company = Vet(person1, person2)
companyCopy = copy.deepcopy(company)
companyCopy.owner.age = 36
print(f"new age = {companyCopy.owner.age}")
print(f"old age = {company.owner.age}")




