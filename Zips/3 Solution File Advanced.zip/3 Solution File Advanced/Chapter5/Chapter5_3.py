import functools

def repeat(times):
    ''' this function decorator will repeat a message '''
    def decorate(functionPlace):
        @functools.wraps(functionPlace)
        def wrapper(*args, **kwargs):
            for _ in range(times):
                youSay = functionPlace(*args, **kwargs)
            return youSay
        return wrapper
    return decorate

@repeat(5)
def say(message):
    print(message)

say('I wish to say Good Morning, 5 times.')

