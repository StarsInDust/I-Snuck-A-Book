
def repeat(times):
    ''' this function decorator will repeat a message '''
    def myDecorator(functionPlace):
        def wrapItUp(*args, **kwargs):
            for _ in range(times):
                youSay = functionPlace(*args, **kwargs)
            return youSay
        return wrapItUp
    return myDecorator

@repeat(5)
def say(message):
    print(message)


say('I wish to say Good Morning, 5 times.')

