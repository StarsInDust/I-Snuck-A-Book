
# Using a Decorator on a class

def checkIfInteger(functionPlace):
	def insideFunction(isItInteger):
		if not isinstance(isItInteger._val1, int) or not isinstance(isItInteger._val2, int):
			raise TypeError('val1 and val2 must be integers')
		else:
			return functionPlace(isItInteger)
	return insideFunction




class SomeMath(object):
	def __init__(self, val1, val2):
		self._val1 = val1
		self._val2 = val2

	@checkIfInteger
	def multiplyThese(self):
		return self._val1 * self._val2

	def power(self, exponent):
		return self.multiplyThese() ** exponent


y = SomeMath(4, 3)

print(y.multiplyThese())
print(y.power(2))

