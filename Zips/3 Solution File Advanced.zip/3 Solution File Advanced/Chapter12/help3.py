import logging

from logging.handlers import TimedRotatingFileHandler
import time

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

handler = TimedRotatingFileHandler('myTimedLog', when='s', interval=5)
logger.addHandler(handler)

for _ in range(6):
    logger.info('I am being created every five seconds')

    time.sleep(5)
