import logging
from logging.handlers import RotatingFileHandler

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

''' This will roll over after 2kb, so it will produce
multiple files.'''

handler = RotatingFileHandler('app.log', maxBytes =2000, backupCount=5)

logger.addHandler(handler)



for _ in range(10000):
    logger.info('Good Day Everyone!')



    