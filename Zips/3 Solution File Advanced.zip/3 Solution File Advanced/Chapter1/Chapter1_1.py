from tkinter import *

window =Tk()
window.title('Basic Code Setup')
window.geometry('600x400')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)

window.mainloop()