from tkinter import *

window =Tk()
window.title('Tuples')
window.geometry('800x200')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background='#b7787a')

movies = ("2001: A Space Odyssey", "The Godfather", "Raiders of the lost Arc", "Seven Samurai ", "The Dark Knight")

(science_fiction, thriller, *action) = movies
print(science_fiction)
print(thriller)
print(action)

myLabel1 = Label(
window, 
text = science_fiction,
font=('Times New Roman', 20, 'bold'),
fg= "#a05a5d",
bg='#e4bdbf',
relief =RAISED,bd=3)

myLabel1.pack()

myLabel2 = Label(
window, 
text = thriller,
font=('Times New Roman', 20, 'bold'),
fg= "#a05a5d",
bg='#e4bdbf',
relief =RAISED,bd=3)

myLabel2.pack()

myLabel3 = Label(
window, 
text = action,
font=('Times New Roman', 20, 'bold'),
fg= "#a05a5d",
bg='#e4bdbf',
relief =RAISED,bd=3)

myLabel3.pack()

window.mainloop()