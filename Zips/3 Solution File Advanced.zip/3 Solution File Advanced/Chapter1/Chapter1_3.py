from tkinter import *

window =Tk()
window.title('Accessing a Tuple')
window.geometry('400x200')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background='#b7787a')


myTupple = ('Sara', 'Teacher', 38, 'Tom', 'Lawyer', 45)


myLabel = Label(
window, 
#text = myTupple[1],
#text = myTupple[-1],
#text = myTupple[3:6],
#text = myTupple[:4],
text = myTupple[1:],
font=('Times New Roman', 20, 'bold'),
fg= "#a05a5d",
bg='#e4bdbf',
relief =RAISED,
bd=3

)
myLabel.pack()


window.mainloop()