from tkinter import *

window =Tk()
window.title('Tuples')
window.geometry('400x200')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background='#b7787a')

animals = ('Alligator', 'Badger', 'Cat')

(water, land, house) = animals

myLabel1 = Label(
window, 
text = water,
font=('Times New Roman', 20, 'bold'),
fg= "#a05a5d",
bg='#e4bdbf',
relief =RAISED,
bd=3

)
myLabel1.pack()

myLabel2 = Label(
window, 
text = land,
font=('Times New Roman', 20, 'bold'),
fg= "#a05a5d",
bg='#e4bdbf',
relief =RAISED,
bd=3

)
myLabel2.pack()

myLabel3 = Label(
window, 
text = house,
font=('Times New Roman', 20, 'bold'),
fg= "#a05a5d",
bg='#e4bdbf',
relief =RAISED,
bd=3

)
myLabel3.pack()

window.mainloop()