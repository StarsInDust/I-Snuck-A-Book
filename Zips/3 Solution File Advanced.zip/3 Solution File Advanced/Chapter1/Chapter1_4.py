from tkinter import *

window =Tk()
window.title('Accessing a Tuple')
window.geometry('400x200')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background='#b7787a')


myTupple = ('Sara', 'Teacher', 38)
myList = list(myTupple)

myList[0] = 'Maranda'

myTupple = tuple(myList)


myLabel = Label(
window, 
text = myTupple,
font=('Times New Roman', 20, 'bold'),
fg= "#a05a5d",
bg='#e4bdbf',
relief =RAISED,
bd=3

)
myLabel.pack()


window.mainloop()