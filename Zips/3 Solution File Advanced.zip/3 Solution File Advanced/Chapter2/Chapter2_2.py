
with open('hello_world.txt', 'r') as file:

    print('The file is open')

    myFile = file.readlines()

    for value in myFile:
        print(value, end='')

if file.closed :
    print("\nThe file is closed.")