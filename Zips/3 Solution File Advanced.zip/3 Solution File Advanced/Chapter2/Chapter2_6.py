from tkinter import *

window =Tk()
window.title('Tuples')
window.geometry('400x200')

icon = PhotoImage(file='images\icon.png')
window.iconphoto(True, icon)
window.config(background='#b7787a')

with open('hello.txt', 'r') as file:
    print('The file is open')
    myFile = file.readlines()

    for value in myFile:
        print(value, end='')

if file.closed :
    print("\nThe file is closed.")

myLabel = Label(
window, 
text = str(value),
font=('Times New Roman', 20, 'bold'),
fg= "#a05a5d",
bg='#e4bdbf',
wraplength=400,
justify=LEFT,
relief =RAISED,bd=3)

myLabel.pack()

window.mainloop()

























