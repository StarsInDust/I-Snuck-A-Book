

with open('hello_world.txt', 'w') as file:

    print('The file is open')

    myFile = file.writelines( 'This is my file')

if file.closed :
    print("The file is closed.")