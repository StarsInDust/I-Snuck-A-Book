
def myLittleGenerator():
    yield 1
    yield 2
    yield 3
    yield 4


myGen = myLittleGenerator()

print(max(myGen))
