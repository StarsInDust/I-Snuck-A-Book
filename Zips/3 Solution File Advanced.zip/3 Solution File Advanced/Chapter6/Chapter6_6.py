
def bracelet(x):
    beads =[]
    bead = 10
    
    while bead > x:
        beads.append(bead)
        bead -= 1
    return beads


print(bracelet(0))
print(" ")
print(sum(bracelet(0)))
