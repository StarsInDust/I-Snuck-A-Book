def reachForTheSky(x):
    print('Commencing Count Now!')
    while x < 10:
        yield x 
        x += 1

reachUp = reachForTheSky(1) 


print(next(reachUp))
print(next(reachUp))
print(next(reachUp))
print(next(reachUp))
print(next(reachUp))
print(next(reachUp))
print(next(reachUp))
print(next(reachUp))
print(next(reachUp))




