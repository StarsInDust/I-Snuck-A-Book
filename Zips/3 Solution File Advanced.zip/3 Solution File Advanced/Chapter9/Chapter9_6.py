from multiprocessing import Pool


def double(nums):
    return nums * 2



if __name__ == '__main__':
    nums = range(6)
    myPool = Pool()

    answer = myPool.map(double, nums)
    myPool.close()
    myPool.join()
    print(answer)

