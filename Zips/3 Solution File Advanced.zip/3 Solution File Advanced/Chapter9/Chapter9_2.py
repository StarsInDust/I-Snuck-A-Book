from multiprocessing import Process, Value, Array, Lock
import time

def addNum(num, lock):
    for i in range(100):
        time.sleep(0.1)
        lock.acquire()
        num.value += 2
        lock.release()

    

if __name__ == '__main__':

    lock =Lock()
    
    sharedNum = Value('i', 0)
    print('The starting number is: ', sharedNum.value)
   

    process1 = Process(target= addNum, args=(sharedNum, lock,))
    process2 = Process(target= addNum, args=(sharedNum, lock,))

    process1.start()
    process2.start()

    process1.join()
    process2.join()

    print('This is the number we will have at the end: ',sharedNum.value)

