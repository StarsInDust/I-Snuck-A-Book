from threading import Thread, Lock
import time

databaseValue = 0

def increase(lock):
    global databaseValue 
    
    lock.acquire()

    #dummy code to get info from a database and store it in a local
    
    local_copy = databaseValue
    local_copy += 1
    time.sleep(0.1)
    databaseValue = local_copy
    
    # unlock the state
    lock.release()

if __name__ == "__main__":
  
    lock = Lock()
    
    print('Starting Job: ', databaseValue)

    thread1 = Thread(target=increase, args=(lock,)) 
    thread2 = Thread(target=increase, args=(lock,))

    thread1.start()
    thread2.start()

    thread1.join()
    thread2.join()

    print('Starting Job:', databaseValue)

    print('The Job has finished')
