import re

MyList = ["Let's check this", 'Probably not there']
text = "Let's check this"
for matchIt in MyList:
    print ('Looking for "%s" in "%s" ->' % (matchIt, text))
    if re.search(matchIt, text):
        print ('I Found IT!')
        
else:
    print ("Opps, it's not here")
