import re

myText = "John Mary Sam Norma Pete Andrea."
listThis = re.split("\s", myText)
print(listThis)

