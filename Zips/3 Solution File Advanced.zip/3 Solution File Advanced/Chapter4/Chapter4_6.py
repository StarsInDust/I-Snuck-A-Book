from itertools import permutations
   
print ("We have 3 items in a range, but here we are stating we only want to see 2 of them in a set")
 
print(list(permutations(range(3), 2)))