from itertools import permutations
   
print ("All the permutations, or ways we can arrange this list are:") 
print (list(permutations([1, 'Unicorn'], 2)))
print()
 
   
print ("All the permutations, or ways we can arrange this list are:") 
print (list(permutations(['A', 'B', 'C'], 3)))
print()
 