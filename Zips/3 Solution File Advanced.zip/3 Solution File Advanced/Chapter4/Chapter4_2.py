import itertools

count = 0

for index in itertools.cycle('ABCD'):
    if count > 20:
        break
    else:
        print(index, end = " ")
        count += 1