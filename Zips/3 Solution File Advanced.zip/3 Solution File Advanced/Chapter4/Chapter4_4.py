import itertools
  
  
Teams = [("Monster", "Dracula"), 
          ("Monster", "Frankenstein"), 
          ("Monster", "Lock Ness Monster"), 
          ("Hero", "Superman"),("Hero", "Batman"),
          ("Hero", "Spiderman")
          
          ]
  
  
an_iterator = itertools.groupby(Teams, lambda x : x[0])
  
for key, group in an_iterator:
    key_and_group = {key : tuple(group)}
    print(f'This group is: {key_and_group} ')


