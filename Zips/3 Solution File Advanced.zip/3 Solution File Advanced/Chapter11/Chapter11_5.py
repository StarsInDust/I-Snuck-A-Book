import pickle


class Student:
    def __init__(self, name, gradeLevel, school ) :
        self.name = name
        self.gradeLevel = gradeLevel
        self.school = school

    def printStudent(self):
        print(self.name)
        print(self.gradeLevel)
        print(self.school)

    def graduateTo(self, newGradeLevel):
        self.gradeLevel += newGradeLevel

student1 = Student('Jessie', 9, 'John F. Kennedy')

with open('Jessie.pickle', 'rb') as file:
    pickle.load(file)

student1.printStudent()