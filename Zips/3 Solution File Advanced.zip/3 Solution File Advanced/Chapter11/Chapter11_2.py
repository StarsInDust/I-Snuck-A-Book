with open ('aDataFile', 'r') as file:
    myData = file.read().splitlines()

    text = myData [0]
    number = int(myData[1])
    floating = float(myData[2])

print(text)
print(number)
print(floating)

